<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]>      <html class="no-js"> <!--<![endif]-->
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Index page</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="">
</head>

<body>
    <p>
        <a href="./01_ThemXe.php">A. Thêm Xe</a>
        <br>
        <a href="./02_ThemHopDong.php">B. Thêm Hợp Đồng</a>
        <br>
        <a href="./03_LietKeHopDong.php">C. Liệt Kê Hợp Đồng</a>
        <br>
        <a href="./04_LietKeXe.php">D. Liệt Kê Xe </a>
        <br>
        <a href="./05_ThongTinChiTiet.php">E. Update Thông Tin Xe</a>
        <br>
    </p>
</body>

</html>