<!DOCTYPE html>
<html>

<head>
    <title>03 Liệt Kê Hợp Đồng</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk=" crossorigin="anonymous"></script>
    <script>
       
    </script>
</head>


<body>
    <div class="container">
        <h2>Liệt kê hợp đồng</h2>
        <form method="get" action="#">
            <table>
                <tr>
                    <td>Nhập số lượng</td>
                    <td><input type="text" name="sl" id="sl"></td>
                </tr>
            </table>
            <table border="1" cellspacing="1" id="dshoadon">
            </table>
        </form>
</body>

</html>